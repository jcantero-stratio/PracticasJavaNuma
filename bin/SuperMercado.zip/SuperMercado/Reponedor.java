package SuperMercado;

public interface Reponedor {

	

	public void reponerStock() throws Exception;
		
	
	
}
