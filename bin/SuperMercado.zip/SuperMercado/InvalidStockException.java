package SuperMercado;

public class InvalidStockException extends Exception{

	
}
